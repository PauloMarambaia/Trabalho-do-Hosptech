'use strict';
const {
  Model
} = require('sequelize');
const { FOREIGNKEYS } = require('sequelize/lib/query-types');
module.exports = (sequelize, DataTypes) => {
  class Consulta extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Consulta.hasMany(models.Especialidade,
        { foreignKey: 'ConsultaId', }
      );
      Consulta.belongsToMany(models.Especialidade,
        { foreignKey: 'ConsultaId', through: 'Especialidade', }
      );
    }
  }
  Consulta.init({
    endereço: DataTypes.STRING,
    email: DataTypes.STRING,
    dataConsulta: DataTypes.STRING,
    dataConsulta: DataTypes.DATE
  }, {
    sequelize,
    modelName: 'Consulta',
  });
  return Consulta;
};