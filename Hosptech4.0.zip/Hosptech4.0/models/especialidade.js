'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Especialidade extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Especialidade.belongsTo(models.Paciente,
        {foreignKey: 'PacienteId', }
      );
      Especialidade.belongsTo(models.Hospital,
        {foreignKey: 'HospitalId'}
      );
      Especialidade.belongsToMany(models.Consulta,
        {foreignKey: 'ConsultaId', }
      );
      Especialidade.hasMany(models.Especialidade, 
        {foreignKey: 'EspecialidadeId', }
      );
    }
  }
  Especialidade.init({
    numConsulta: DataTypes.INTEGER,
    dataConsulta: DataTypes.STRING,
    status: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Especialidade',
  });
  return Especialidade;
};